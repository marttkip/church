<head>
    <meta charset="utf-8" />
    <title>Dominion Generation | <?php echo $title;?></title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <!-- Mobile Specific Metas
      ================================================== -->
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
    <meta name="format-detection" content="telephone=no">
    <!-- CSS
      ================================================== -->
    <link href="<?php echo site_url()?>assets/themes/adore/css/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="<?php echo site_url()?>assets/themes/adore/css/bootstrap-theme.css" rel="stylesheet" type="text/css">
    <link href="<?php echo site_url()?>assets/themes/adore/css/style.css" rel="stylesheet" type="text/css">
    <link href="<?php echo site_url()?>assets/themes/adore/vendor/prettyphoto/css/prettyPhoto.css" rel="stylesheet" type="text/css">
    <link href="<?php echo site_url()?>assets/themes/adore/vendor/mediaelement/mediaelementplayer.css" rel="stylesheet" type="text/css">
    <!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="<?php echo site_url()?>assets/themes/adore/css/ie.css" media="screen" /><![endif]-->
    <link href="<?php echo site_url()?>assets/themes/adore/css/custom.css" rel="stylesheet" type="text/css"><!-- CUSTOM STYLESHEET FOR STYLING -->
    <!-- Color Style -->
    <link class="alt" href="<?php echo site_url()?>assets/themes/adore/colors/color1.css" rel="stylesheet" type="text/css">
    <link href="<?php echo site_url()?>assets/themes/adore/style-switcher/css/style-switcher.css" rel="stylesheet" type="text/css">
    <!-- SCRIPTS
      ================================================== -->
    <script src="<?php echo site_url()?>assets/themes/adore/js/modernizr.js"></script><!-- Modernizr -->
</head>